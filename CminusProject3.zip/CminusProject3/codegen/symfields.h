#ifndef SYMFIELDS_H_
#define SYMFIELDS_H_

#define SYMTAB_OFFSET_FIELD "variable_offset"						/**< The symbol table field for variable offset */
#define SYMTAB_SIZE_FIELD "variable_offset"
#define SYMTAB_NAME_FIELD "variable_offset"



#endif /*SYMFIELDS_H_*/
