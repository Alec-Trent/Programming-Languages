#ifndef SYMFIELDS_H_
#define SYMFIELDS_H_

#define SYMTAB_OFFSET_FIELD "variable_offset"						/**< The symbol table field for variable offset */
#define SYMTAB_TYPE_INDEX_FIELD "variable_type"						/**< The symbol table field for data types */


#endif /*SYMFIELDS_H_*/
